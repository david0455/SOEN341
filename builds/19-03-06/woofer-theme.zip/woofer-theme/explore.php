<?php
/*
*
* Template Name: explore
*
*
*/
$current_user = wp_get_current_user();
$currID = $current_user->ID;
get_header();
?>
<h1 style="margin:100px;">
  Displaying all woofs ever
</h1>

<?php echo get_template_part( 'show-woofs-on-explore.php' ); ?>

<?php
get_footer();
?>
