<?php
/*
* Template Name: following
*/
get_header();
?>

<h1 style="margin:50px;">
  Woofs by people you tail
</h1>

<?php echo get_template_part( 'show-woofs-on-follow.php' ); ?>