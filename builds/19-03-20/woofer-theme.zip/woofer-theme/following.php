<?php
/*
* Template Name: following
*/
get_header();
?>
<div class="woof-main-content full">
  <h1 class="woofer-page-title">
    Woofs by people you tail
  </h1>
    <?php echo get_template_part('/template-parts/show-woofs-on-follow'); ?>

</div>


<?php
get_footer();
?>
