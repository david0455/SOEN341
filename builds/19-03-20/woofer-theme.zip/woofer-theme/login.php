<?php
/*
*
* Template Name: login
*
*
*/
get_header();
?>

<div class="woof-main-content full">
  <h1 class="woofer-page-title">
  Login
</h1>

  <div style="margin:50px;">
    <?php
    woof_custom_login();

    ?>
  </div>
</div>

<?php
get_footer();
?>
